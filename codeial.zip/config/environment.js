
const development = {
    name : 'development',
    asset_path : './assets',
    session_cookie_key: 'blahsomething',
    db :'codeial_development',
    smtp : {
        service: 'gmail',
        host: 'smtp.gmail.com',
        port: 587,
        secure: false,
        auth: {
             user: 'projectcodeial694@gmail.com',
             password: 'srafxwfgcipirwvj'

        }
    },
    google_client_id: "812683272374-raas3fkm3pabhlhe11iu17kpvd0vn9bn.apps.googleusercontent.com",
    google_client_secret: "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",
    google_call_back_URL: "http://localhost:8000/users/auth/google/callback",
    jwt_secret: 'codeial'
}

const production = {
    name : 'production'
}

module.exports = development;